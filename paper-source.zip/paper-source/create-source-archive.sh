#!/usr/bin/env bash
git archive  --prefix="paper-source/" --format=zip HEAD . > paper-source.zip
